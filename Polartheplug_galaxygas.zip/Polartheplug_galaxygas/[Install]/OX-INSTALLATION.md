██████╗  ██████╗ ██╗      █████╗ ██████╗     ███╗   ███╗███████╗██╗     ███████╗███████╗    ██████╗  █████╗  ██████╗██╗  ██╗
██╔══██╗██╔═══██╗██║     ██╔══██╗██╔══██╗    ████╗ ████║██╔════╝██║     ██╔════╝██╔════╝    ██╔══██╗██╔══██╗██╔════╝██║ ██╔╝
██████╔╝██║   ██║██║     ███████║██████╔╝    ██╔████╔██║█████╗  ██║     █████╗  █████╗      ██████╔╝███████║██║     █████╔╝ 
██╔═══╝ ██║   ██║██║     ██╔══██║██╔══██╗    ██║╚██╔╝██║██╔══╝  ██║     ██╔══╝  ██╔══╝      ██╔═══╝ ██╔══██║██║     ██╔═██╗ 
██║     ╚██████╔╝███████╗██║  ██║██║  ██║    ██║ ╚═╝ ██║███████╗███████╗███████╗███████╗    ██║     ██║  ██║╚██████╗██║  ██╗
╚═╝      ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝     ╚═╝╚══════╝╚══════╝╚══════╝╚══════╝    ╚═╝     ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝


-- STEP 1: Put Polartheplug_galaxygas folder into your resources then ensure it in your server.cfg
-- STEP 2: ADD IMAGES THAT ARE IN THE INSTALL FOLDER TO OX_INVENTORY    [ox_inventory/web/images]                                     


-- STEP 3: PUT THIS IN OX_INVENTORY > DATA > WEAPONS.LUA AND PUT IT IN THE SECTION WHERE ALL THE WEAPONS ARE AT 


['WEAPON_GAS'] = {
	label = 'Galaxy Gas',
	weight = 450,
},


				
			