██████╗  ██████╗ ██╗      █████╗ ██████╗     ███╗   ███╗███████╗██╗     ███████╗███████╗    ██████╗  █████╗  ██████╗██╗  ██╗
██╔══██╗██╔═══██╗██║     ██╔══██╗██╔══██╗    ████╗ ████║██╔════╝██║     ██╔════╝██╔════╝    ██╔══██╗██╔══██╗██╔════╝██║ ██╔╝
██████╔╝██║   ██║██║     ███████║██████╔╝    ██╔████╔██║█████╗  ██║     █████╗  █████╗      ██████╔╝███████║██║     █████╔╝ 
██╔═══╝ ██║   ██║██║     ██╔══██║██╔══██╗    ██║╚██╔╝██║██╔══╝  ██║     ██╔══╝  ██╔══╝      ██╔═══╝ ██╔══██║██║     ██╔═██╗ 
██║     ╚██████╔╝███████╗██║  ██║██║  ██║    ██║ ╚═╝ ██║███████╗███████╗███████╗███████╗    ██║     ██║  ██║╚██████╗██║  ██╗
╚═╝      ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝     ╚═╝╚══════╝╚══════╝╚══════╝╚══════╝    ╚═╝     ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝


-- STEP 1: ensure script
	

-- STEP 2: add images


-- STEP 3: ADD FIRST CODE LIST TO    ■   [qb-core/shared/items.lua]                                    ■  under the | QBShared.Items = 

weapon_gas = { name = 'weapon_gas', label = 'Galaxy Gas', weight = 500, type = 'weapon', ammotype = nil, image = 'weapon_gas.png', unique = false, useable = true, description = 'A gas canister, perfect for close combat.' },




-- STEP 4: ADD SECOND CODE LIST TO   ■   [qb-core/shared/weapons.lua]                                  ■  under the | QBShared.Weapons =


['weapon_gas']       = { name = 'weapon_gas', label = 'Bladed Bat', weapontype = 'Melee', ammotype = nil, damagereason = 'Bludgeoned' },




-- STEP 5: ADD THIRD CODE LIST TO    ■   [qb-smallresources/client/weapdraw.lua]                       ■  under the | local weapons = {

'weapon_gas',




-- STEP 6: ADD FOURTH CODE LIST TO   ■   [qb-weapons/config.lua]                                ■  under the | Config.DurabilityMultiplier = 


weapon_gas        = 0.15,



