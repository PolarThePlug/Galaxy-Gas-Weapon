AddTextEntry("WEAPON_GAS", "gascan")
